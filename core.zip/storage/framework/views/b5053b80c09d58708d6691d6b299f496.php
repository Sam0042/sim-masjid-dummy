
<?php $__env->startSection('konten'); ?>
    <h1>testing</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/surat/index.blade.php ENDPATH**/ ?>