
<?php $__env->startSection('konten'); ?>
    <section
        style="background-image: url('/admin/image/3.jpeg'); 
           background-size: cover; 
           background-position: 50% 30%; 
           height: 95vh; 
           width: 100%; 
           position: relative;
           ">

        <!-- overlay hitam transparan -->
        <div
            style="position: absolute; top:0; left:0; width:100%; height:100%; 
                background-color: rgba(0,0,0,0.8);">
        </div>

        <!-- konten teks -->
        <div class="d-flex flex-column justify-content-center align-items-center h-100"
            style="position: relative; z-index: 1;">
            <h1 class="text-white fw-bold text-center mb-4" style="font-size: 50px">
                KAS OPERASIONAL
            </h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item">
                    <a href="/" class="text-white fw-semibold text-decoration-none">Beranda</a>
                </li>
                <li class="breadcrumb-item active text-info fw-semibold">Kas Operasional</li>
            </ol>

        </div>
    </section>


    <div style="background-color: lightgrey">



        <div class="container py-4">
            <div class="row justify-content-center g-4">
                <h1 class="text-center fw-bold text-dark mb-4 mt-5">Data Kas Operasional</h1>
                <div class="container-fluid px-4">
                    <div class="card mb-4">

                    </div>
                    <div class="card mb-4">

                        <div class="card-body">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Keterangan</th>
                                        <th>Jenis</th>
                                        <th>Nominal</th>

                                    </tr>
                                </thead>
                                <tfoot>
                                    <th>No</th>

                                    <th>Tanggal</th>
                                    <th>Keterangan</th>
                                    <th>Jenis</th>
                                    <th>Nominal</th>
                                </tfoot>
                                <tbody>

                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>

                                            <td><?php echo e($d->tanggal); ?></td>
                                            <td><?php echo e($d->keterangan); ?></td>
                                            <td><?php echo e($d->jenis); ?></td>
                                            <td><?php echo e(number_format($d->nominal, 0, ',', '.')); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title mb-3 text-center">Print Berdasarkan Bulan dan Tahun</h5>
                        </div>
                        <div class="card-body">
                            <form id="printForm" class="row g-3 align-items-end" onsubmit="return false;">
                                <div class="col-md-4">
                                    <label for="bulan" class="form-label">Bulan</label>
                                    <select id="bulan" name="bulan" class="form-select" required>
                                        <option value="" disabled selected>Pilih Bulan</option>
                                        <?php $__currentLoopData = $availableMonthsYears->unique('bulan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $monthNumber = str_pad($item->bulan, 2, '0', STR_PAD_LEFT);
                                                $monthName = \Carbon\Carbon::create()
                                                    ->month($item->bulan)
                                                    ->translatedFormat('F');
                                            ?>
                                            <option value="<?php echo e($monthNumber); ?>"><?php echo e($monthName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-4">
                                    <label for="tahun" class="form-label">Tahun</label>
                                    <select id="tahun" name="tahun" class="form-select" required>
                                        <option value="" disabled selected>Pilih Tahun</option>
                                        <?php $__currentLoopData = $availableMonthsYears->unique('tahun'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->tahun); ?>"><?php echo e($item->tahun); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-4 d-flex justify-content-start">
                                    <button type="button" id="tambahBtn" class="btn btn-primary btn-md mt-2">
                                        <i class="bi bi-printer-fill"></i> Tampilkan Tombol Print
                                    </button>
                                </div>
                            </form>

                            <div id="tombolContainer" class="mt-4 d-flex flex-wrap gap-2"></div>
                        </div>
                    </div>

                    <script>
                        document.getElementById('tambahBtn').addEventListener('click', function() {
                            const bulan = document.getElementById('bulan').value;
                            const tahun = document.getElementById('tahun').value;

                            if (!bulan || !tahun) {
                                alert('Pilih bulan dan tahun terlebih dahulu!');
                                return;
                            }

                            const bulanNama = new Date(tahun, bulan - 1).toLocaleString('id-ID', {
                                month: 'long'
                            });
                            const container = document.getElementById('tombolContainer');

                            const tombol = document.createElement('a');
                            tombol.href = `/kas-operasional/print/${tahun}/${bulan}`;
                            tombol.target = "_blank";
                            tombol.textContent = `Cetak Laporan ${bulanNama} ${tahun}`;
                            tombol.classList = "btn btn-success";
                            tombol.style.marginRight = "10px";

                            container.appendChild(tombol);
                        });
                    </script>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/front/zakatFitrah/index.blade.php ENDPATH**/ ?>