<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <?php if(auth()->guard()->check()): ?>

                        <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>

                        <a class="nav-link" href="/">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Beranda
                        </a>
                        
                    <?php endif; ?>

                    
                    <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                        <div class="sb-sidenav-menu-heading">Interface</div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Jadwal Imam
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                
                                <?php if(auth()->guard()->check()): ?>
                                    <a class="nav-link" href="<?php echo e(route('imam.index')); ?>">Imam</a>
                                    <a class="nav-link" href="<?php echo e(route('imamJumat.index')); ?>">Jadwal Imam Jumat</a>
                                    <a class="nav-link" href="<?php echo e(route('imamFardhu.index')); ?>">Jadwal Imam Fardhu</a>
                                <?php endif; ?>
                                <?php if(auth()->guard()->guest()): ?>
                                    <a class="nav-link" href="<?php echo e(route('imamJumat-front.index')); ?>">Jadwal Imam Jumat</a>
                                    <a class="nav-link" href="<?php echo e(route('imamFardhu-front.index')); ?>">Jadwal Imam Fardhu</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts1" aria-expanded="false"
                            aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Buletin
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts1" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">

                                <a class="nav-link" href="<?php echo e(route('program.index')); ?>">Program</a>

                            </nav>
                        </div>
                    <?php endif; ?>

                    



                    
                    <?php if(Auth::check() && Auth::user()->role === 'bendahara'): ?>
                        <div class="sb-sidenav-menu-heading">Keuangan</div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts3" aria-expanded="false"
                            aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Keuangan
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts3" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <a class="nav-link" href="<?php echo e(route('keterangan_kas.index')); ?>">
                                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i>
                                    </div>
                                    Keterangan Kas
                                </a>
                            </nav>
                            

                        </div>
                    <?php endif; ?>




                    
                    

                    <?php if(Auth::check() && Auth::user()->role === 'ketua'): ?>
                        <div class="sb-sidenav-menu-heading">Interface</div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Jadwal Imam
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">

                                <a class="nav-link" href="<?php echo e(route('imamJumat-front.index')); ?>">Jadwal
                                    Imam Jumat</a>
                                <a class="nav-link" href="<?php echo e(route('imamFardhu-front.index')); ?>">Jadwal
                                    Imam Fardhu</a>
                            </nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts1" aria-expanded="false"
                            aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Buletin
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts1" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">

                                <a class="nav-link" href="<?php echo e(route('program-front.index')); ?>">Program</a>

                            </nav>
                        </div>
                    <?php endif; ?>
                    <?php if(Auth::check() && Auth::user()->role === 'ketua'): ?>
                        <a class="nav-link" href="/kas/print-front">
                            <div class="sb-nav-link-icon"><i class="fas fa-user fa-fw"></i></div>
                            Kas Operasional
                        </a>
                    <?php endif; ?>

                    
                    <?php if(auth()->guard()->guest()): ?>
                        <div class="sb-sidenav-menu-heading">Interface</div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Jadwal Imam
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">
                                <?php if(auth()->guard()->guest()): ?>
                                    <a class="nav-link" href="<?php echo e(route('imamJumat-front-web.index')); ?>">Jadwal
                                        Imam
                                        Jumat</a>
                                    <a class="nav-link" href="<?php echo e(route('imamFardhu-front-web.index')); ?>">Jadwal
                                        Imam
                                        Fardhu</a>
                                <?php endif; ?>
                            </nav>
                        </div>
                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                            data-bs-target="#collapseLayouts1" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                            Buletin
                            <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                        </a>
                        <div class="collapse" id="collapseLayouts1" aria-labelledby="headingOne"
                            data-bs-parent="#sidenavAccordion">
                            <nav class="sb-sidenav-menu-nested nav">

                                <a class="nav-link" href="<?php echo e(route('program-front-web.index')); ?>">Program</a>

                            </nav>
                        </div>
                    <?php endif; ?>

            </div>
        </div>
        <div class="sb-sidenav-footer">
            <?php if(auth()->guard()->check()): ?>
                <div class="small">Logged in as:</div>
                <?php echo e(Auth::user()->name); ?>

            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                Guest
            <?php endif; ?>
        </div>
    </nav>
</div>
<div id="layoutSidenav_content">
    <main>
<?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>