<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hello Ini file pertama saya didalam view laravel</h1>
    <?php
    $nama = 'Budi';
    $nilai = 70.00;
    ?>
    
    <?php if($nilai >= 60): ?>
    <?php $ket = "lulus"; ?>
    <?php else: ?> 
    <?php $ket = "tidak lulus"; ?>
    <?php endif; ?>

    
    <?php echo e($nama); ?> <p> Dengan nilai </p> <?php echo e($nilai); ?> <p>Dinyatakan </p> <?php echo e($ket); ?>



    
</body>
</html><?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/hello.blade.php ENDPATH**/ ?>