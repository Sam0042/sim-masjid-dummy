 

<?php $__env->startSection('konten'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Backup Database</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Backup Database</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-database me-1"></i>
                Aksi Backup
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('backup.run')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-cloud-upload-alt me-1"></i> Jalankan Backup Sekarang
                    </button>
                </form>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-file-archive me-1"></i>
                Daftar File Backup
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama File</th>
                            <th>Tanggal Backup</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama File</th>
                            <th>Tanggal Backup</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(basename($file)); ?></td>
                                <td><?php echo e(date('d-m-Y H:i:s', filemtime($file))); ?></td>
                                <td>
                                    <a href="<?php echo e(route('backup.download', basename($file))); ?>"
                                        class="btn btn-sm btn-success">
                                        <i class="fas fa-download"></i> Download
                                    </a>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/backup/index.blade.php ENDPATH**/ ?>