<?php $__env->startSection('content'); ?>
    <header class="bg-dark py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder">Shop in style</h1>
                <p class="lead fw-normal text-white-50 mb-0">With this shop hompeage template</p>
            </div>
        </div>
    </header>
    <!-- Section-->
    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">

            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col mb-5">


                        <div class="card h-100">
                            <!-- Product image-->
                            <?php if(empty($p->foto)): ?>
                                <img class="card-img-top" src="<?php echo e(url('admin/image/nophoto.jpg')); ?>" alt="..." />
                            <?php else: ?>
                                <img class="card-img-top" src="<?php echo e(url('admin/image')); ?>/<?php echo e($p->foto); ?>" alt="..." />
                            <?php endif; ?>
                            <!-- Product details-->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name-->
                                    <h5 class="fw-bolder"><?php echo e($p->nama); ?></h5>
                                    <!-- Product price-->
                                    Rp.<?php echo e(number_format($p->harga_jual, 0, ',', '.')); ?>

                                </div>
                            </div>
                            <!-- Product actions-->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a
                                        class="btn btn-outline-dark  border border-1 border-dark mt-auto"
                                        href="<?php echo e(url('detail_cart/' . $p->id)); ?>">View Details</a></div>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center">
                                        <a class="btn btn-outline-light btn-dark border border-1 border-dark mt-auto"
                                            href="<?php echo e(route('add.to.cart', $p->id)); ?>">
                                            Add To Cart</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/front/home.blade.php ENDPATH**/ ?>