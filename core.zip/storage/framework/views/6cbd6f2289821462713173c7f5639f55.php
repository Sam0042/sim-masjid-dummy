<?php $__env->startSection('konten'); ?>
    <section
        style="background-image: url(https://lh3.googleusercontent.com/p/AF1QipM-5pvP4pURqaTRv0U5Qz27gPpDKP2ykdq-he3y=s1360-w1360-h1020);
background-size:cover;width:100%;height:450px"
        class="pt-3 pb-3 d-flex ps-5 pe-auto flex-column justify-content-center">
        
        <h1
            style="font-weight:bold;font-size:60px;color:yellow;margin:4rem auto auto auto;text-align:center;
width:80%;text-shadow: 2px 2px 5px black;">
            <i>
                Selamat Datang di Sistem Informasi Masjid Jami Roudhotul Jannah
            </i><br>
        </h1>
        <style>
            p {
                text-align: center;
                color: yellow;
                font-size: 20px;
                text-shadow: 4px 4px 10px black;
            }
        </style>
        <p>Rawa Panjang, Kecamatan Bojonggede, Kabupaten Bogor, Jawa Barat 16920</p>
        <p>Perumahan Taman Raya Citayam Jl Edelia Blok E5 RT.07 RW.12</p>


    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/admin/beranda.blade.php ENDPATH**/ ?>