<a href="<?php echo e(route('kas_operasional.index')); ?>">Kembali</a>
<br>


<div>
    <?php $__currentLoopData = $dataByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <b>Masjid Roudhotul Jannah</b><br>
        <b>Laporan Keuangan</b><br>
        <b>Kas Operasional</b><br>
        <b><?php echo e($month); ?></b>
        <br><br>

        <table style="width:100%; border-collapse: collapse; text-align:center;" border="1">
            <thead>
                <tr>
                    <th rowspan="2">Keterangan</th>
                    <th colspan="<?php echo e($data->groupBy('tanggal')->count()); ?>">Tanggal</th>
                    <th rowspan="2">Jumlah</th>
                </tr>
                <tr>
                    <?php $__currentLoopData = $data->groupBy('tanggal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(\Carbon\Carbon::parse($date)->format('d-M-Y')); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Penerimaan</th>
                    <?php for($i = 0; $i < $data->groupBy('tanggal')->count(); $i++): ?>
                        <td></td>
                    <?php endfor; ?>
                    <td></td>
                </tr>
                <?php $__currentLoopData = $penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggal => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $items->unique('keterangan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->keterangan); ?></td>
                            <?php $totalExpense = 0; ?>
                            <?php $__currentLoopData = $data->groupBy('tanggal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $expense = $item->keterangan;
                                    $amount = $items->where('keterangan', $expense)->sum('nominal');
                                    $totalExpense += $amount;
                                ?>
                                <td><?php echo e(number_format($amount, 0, ',', '.')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalExpense, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>Pengeluaran</th>
                    <?php for($i = 0; $i < $data->groupBy('tanggal')->count(); $i++): ?>
                        <td></td>
                    <?php endfor; ?>
                    <td></td>
                </tr>

                <?php $__currentLoopData = $pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggal => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $items->unique('keterangan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->keterangan); ?></td>
                            <?php $totalExpense = 0; ?>
                            <?php $__currentLoopData = $data->groupBy('tanggal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $expense = $item->keterangan;
                                    $amount = $items->where('keterangan', $expense)->sum('nominal');
                                    $totalExpense += $amount;
                                ?>
                                <td><?php echo e(number_format($amount, 0, ',', '.')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalExpense, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/admin/kasOperasional/print.blade.php ENDPATH**/ ?>