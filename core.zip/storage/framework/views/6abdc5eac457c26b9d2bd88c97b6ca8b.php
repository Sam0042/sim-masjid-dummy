
<?php $__env->startSection('konten'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Data Khotib dan Muazin Jumat</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Tables</li>
        </ol>
        <div class="card mb-4">

        </div>
        <div class="card mb-4">

            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Khotib/Imam</th>
                            <th>Nomor Hp</th>
                            <th>Muazin</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Khotib/Imam</th>
                        <th>Nomor Hp</th>
                        <th>Muazin</th>
                    </tfoot>
                    <tbody>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($d->tanggal)->translatedFormat('l, d F Y')); ?></td>
                                <td><?php echo e($d->khotib); ?></td>
                                <td><?php echo e($d->no_hp); ?></td>
                                <td><?php echo e($d->muazin); ?></td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/ketua/ketua-khotibMuazin.blade.php ENDPATH**/ ?>