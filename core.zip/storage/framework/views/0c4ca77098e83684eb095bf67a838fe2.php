
<?php $__env->startSection('konten'); ?>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Program</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('program.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="imam_id" class="form-label">Nama Program</label>
                        <input type="text" class="form-control" name="nama" id="exampleInputEmail1"
                            aria-describedby="emailHelp" placeholder="Masukkan Nama Program" required>
                        <br>
                        <label for="" class="form-label">Lokasi</label>
                        <input type="text" class="form-control" name="lokasi" id="exampleInputEmail1"
                            aria-describedby="emailHelp" placeholder="Masukkan Lokasi" required>
                        <br>
                        <label for="desk" class="form-label">Deskripsi</label>
                        <textarea class="form-control" name="deskripsi" id="exampleInputEmail1" aria-describedby="emailHelp"
                            placeholder="Masukkan Deskripsi" rows="5" required style="white-space: pre-wrap;"></textarea>

                        <br>
                        <label for="tanggal" class="form-label">Tanggal Mulai</label>
                        <input required type="datetime-local" class="form-control" name="tanggal_mulai" id="tanggalInput"
                            aria-describedby="dateHelp" placeholder="Pilih Tanggal dan Jam"
                            min="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d H:i')); ?>" required>

                        <br>
                        <label for="tanggal" class="form-label">Tanggal Selesai</label>
                        <input required type="datetime-local" class="form-control" name="tanggal_selesai" id="tanggalInput"
                            aria-describedby="dateHelp" placeholder="Pilih Tanggal dan Jam"
                            min="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d H:i')); ?>" required>


                        <br>
                        <label for="tanggal" class="form-label">Foto</label>
                        <input id="text5" name="foto" type="file" class="form-control" required>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ini batas modal -->

    
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editModal<?php echo e($d->id); ?>" tabindex="-1" aria-labelledby="editModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Edit Jadwal</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('program.update', $d->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <label for="imam_id" class="form-label">Nama Program</label>
                            <input type="text" class="form-control" name="nama" id="exampleInputEmail1"
                                aria-describedby="emailHelp" placeholder="Masukkan Nama Program" value="<?php echo e($d->nama); ?>"
                                required>
                            <br>
                            <label for="" class="form-label">Lokasi</label>
                            <input type="text" class="form-control" name="lokasi" id="exampleInputEmail1"
                                aria-describedby="emailHelp" placeholder="Masukkan Lokasi" value="<?php echo e($d->lokasi); ?>"
                                required>
                            <br>
                            <label for="desk" class="form-label">Deskripsi</label>
                            <textarea class="form-control" name="deskripsi" id="exampleInputEmail1" aria-describedby="emailHelp"
                                placeholder="Masukkan Deskripsi" rows="5" required style="white-space: pre-wrap;"><?php echo e($d->deskripsi); ?></textarea>

                            <br>
                            <label for="tanggal" class="form-label">Tanggal Mulai</label>

                            <input required type="datetime-local" class="form-control" name="tanggal_mulai"
                                id="tanggalInput" aria-describedby="dateHelp"
                                min="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d H:i')); ?>"
                                value="<?php echo e(\Carbon\Carbon::parse($d->tanggal_mulai)->format('Y-m-d H:i')); ?>" required>
                            <br>
                            <label for="tanggal" class="form-label">Tanggal Selesai</label>
                            <input required type="datetime-local" class="form-control" name="tanggal_selesai"
                                id="tanggalInput" aria-describedby="dateHelp"
                                min="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d H:i')); ?>"
                                value="<?php echo e(\Carbon\Carbon::parse($d->tanggal_selesai)->format('Y-m-d H:i')); ?>" required>
                            <br>
                            
                            <label for="text5">Foto</label>
                            <input id="text5" name="foto" type="file" class="form-control"
                                value="<?php echo e($d->foto); ?>">
                            <?php if(!empty($d->foto)): ?>
                                <img src="<?php echo e(url('admin/assets/img')); ?>/<?php echo e($d->foto); ?>" alt="project-image"
                                    class=" mt-1" style="width: 250px;height:150px">
                            <?php endif; ?>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <div class="container-fluid px-4">
        <h1 class="mt-4">Program Masjid</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Tables</li>
        </ol>
        <div class="card mb-4">

        </div>
        <?php if(auth()->guard()->check()): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="" class="btn btn-md btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            <i class="fa-solid fa-square-plus"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>No</th>

                                <th>Nama</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Selesai</th>

                                <th>Action</th>

                            </tr>
                        </thead>
                        <tfoot>
                            <th>No</th>

                            <th>Nama</th>
                            <th>Tanggal Mulai</th>
                            <th>Tanggal Selesai</th>

                            <th>Action</th>
                        </tfoot>
                        <tbody>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>

                                    <td><?php echo e($d->nama); ?></td>
                                    <td><?php echo e($d->tanggal_mulai); ?></td>
                                    <td><?php echo e($d->tanggal_selesai); ?></td>


                                    <td>
                                        
                                        <a href="#" class="btn btn-sm btn-warning" data-bs-toggle="modal"
                                            data-bs-target="#editModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-pen-to-square"></i></a>

                                        <!-- ini untuk modal hapus -->
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal<?php echo e($d->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus Produk</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Apakah anda yakin akan menghapus data <?php echo e($d->nama); ?>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>

                                                        <form action="<?php echo e(route('program.destroy', $d->id)); ?>" method="POST"
                                                            style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ini batas modal hapus -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/strukturOrganisasi/index.blade.php ENDPATH**/ ?>