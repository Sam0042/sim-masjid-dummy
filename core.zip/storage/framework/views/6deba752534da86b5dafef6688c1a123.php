
<?php $__env->startSection('konten'); ?>
    <section
        style="background-image: url('/admin/image/3.jpeg'); 
           background-size: cover; 
           background-position: 50% 30%; 
           height: 95vh; 
           width: 100%; 
           position: relative;
           margin-top:50px;">

        <!-- overlay hitam transparan -->
        <div
            style="position: absolute; top:0; left:0; width:100%; height:100%; 
                background-color: rgba(0,0,0,0.8);">
        </div>

        <!-- konten teks -->
        <div class="d-flex flex-column justify-content-center align-items-center h-100"
            style="position: relative; z-index: 1;">
            <h1 class="text-white fw-bold text-center mb-4" style="font-size: 50px">
                SUSUNAN KEPENGURUSAN
            </h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item">
                    <a href="/" class="text-white fw-semibold text-decoration-none">Beranda</a>
                </li>
                <li class="breadcrumb-item active text-info fw-semibold">Susunan Kepengurusan</li>
            </ol>

        </div>
    </section>


    <div style="background-color: lightgrey">

        <div class="container py-4">
            <div class="row justify-content-center g-4">
                <h1>Susunan Kepengurusan</h1>

                <p>Susunan Kepengurusan Masjid Jami Roudhotul Jannah Bojonggede Berikut Ini Menunjukkan Susunan Pengurus
                    Dalam Menjalankan Kegiatan Dan Tanggung Jawab Di Lingkungan Masjid.</p>


                <div class="col-12 d-flex justify-content-center">
                    <div class="card text-white bg-dark card-zoom"
                        style="width: 100%; max-width: 900px; border-radius:15px; transition: transform 0.3s ease, box-shadow 0.3s ease;">

                        <div style="width: 100%; padding: 20px;">
                            <img src="<?php echo e(asset('front/img/struktur-org.jpg')); ?>" alt="Susunan Kepengurusan"
                                style="width: 100%; height: auto; object-fit: contain; border-radius:10px;">
                        </div>


                    </div>

                    <style>
                        .card-zoom:hover {
                            transform: scale(1.03);
                            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
                        }
                    </style>
                </div>
            </div>
        </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/front/strukturOrganisasi/index.blade.php ENDPATH**/ ?>