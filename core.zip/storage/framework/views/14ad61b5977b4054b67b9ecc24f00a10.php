

<?php $__env->startSection('konten'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Log Aktivitas Sistem</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Log Aktivitas</li>
        </ol>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Riwayat Aktivitas User
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Waktu</th>
                            <th>User</th>
                            <th>Aksi</th>
                            <th>Tabel</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Waktu</th>
                            <th>User</th>
                            <th>Aksi</th>
                            <th>Model</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($activity->created_at->format('d M Y H:i')); ?></td>
                                <td><?php echo e($activity->causer ? $activity->causer->name : 'System'); ?></td>
                                <td>
                                    <?php echo e($activity->description); ?>


                                    <?php
                                        $namaData =
                                            $activity->properties['old']['keterangan'] ??
                                            ($activity->properties['attributes']['keterangan'] ?? null);
                                    ?>

                                    <?php if($namaData): ?>
                                        : <strong><?php echo e($namaData); ?></strong>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo e(class_basename($activity->subject_type)); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/logs/index.blade.php ENDPATH**/ ?>