
<?php $__env->startSection('konten'); ?>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Foto</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('laporan.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="bulan" class="form-label">Pilih Bulan</label>
                        <select name="bulan" required>
                            <option value="" disabled>-- Pilih Bulan --</option>
                            <option value="Januari">Januari</option>
                            <option value="Februari">Februari</option>
                            <option value="Maret">Maret</option>
                            <option value="April">April</option>
                            <option value="Mei">Mei</option>
                            <option value="Juni">Juni</option>
                            <option value="Juli">Juli</option>
                            <option value="Agustus">Agustus</option>
                            <option value="September">September</option>
                            <option value="Oktober">Oktober</option>
                            <option value="November">November</option>
                            <option value="Desember">Desember</option>
                        </select>
                        <br>
                        <label for="tahun" class="form-label">Pilih Tahun</label>
                        <select name="tahun" required>
                            <option value="">-- Pilih Tahun --</option>
                            <?php for($i = date('Y'); $i >= 2010; $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(old('tahun') == $i ? 'selected' : ''); ?>>
                                    <?php echo e($i); ?>

                                </option>
                            <?php endfor; ?>

                        </select>
                        <br>
                        <label for="pdf" class="form-label">File PDF</label>
                        <input type="file" name="file_pdf" accept="application/pdf" required><br>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ini batas modal -->

    
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editModal<?php echo e($d->id); ?>" tabindex="-1" aria-labelledby="editModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Edit Data</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('laporan.update', $d->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <label for="bulan" class="form-label">Pilih Bulan</label>
                            <select name="bulan" required>
                                <option value="Januari" <?php echo e($d->bulan == 'Januari' ? 'selected' : ''); ?>>Januari</option>
                                <option value="Februari" <?php echo e($d->bulan == 'Februari' ? 'selected' : ''); ?>>Februari</option>
                                <option value="Maret" <?php echo e($d->bulan == 'Maret' ? 'selected' : ''); ?>>Maret</option>
                                <option value="April" <?php echo e($d->bulan == 'April' ? 'selected' : ''); ?>>April</option>
                                <option value="Mei" <?php echo e($d->bulan == 'Mei' ? 'selected' : ''); ?>>Mei</option>
                                <option value="Juni" <?php echo e($d->bulan == 'Juni' ? 'selected' : ''); ?>>Juni</option>
                                <option value="Juli" <?php echo e($d->bulan == 'Juli' ? 'selected' : ''); ?>>Juli</option>
                                <option value="Agustus" <?php echo e($d->bulan == 'Agustus' ? 'selected' : ''); ?>>Agustus</option>
                                <option value="September" <?php echo e($d->bulan == 'September' ? 'selected' : ''); ?>>September
                                </option>
                                <option value="Oktober" <?php echo e($d->bulan == 'Oktober' ? 'selected' : ''); ?>>Oktober</option>
                                <option value="November" <?php echo e($d->bulan == 'November' ? 'selected' : ''); ?>>November</option>
                                <option value="Desember" <?php echo e($d->bulan == 'Desember' ? 'selected' : ''); ?>>Desember</option>
                            </select>
                            <br>
                            <label for="tahun" class="form-label">Pilih Tahun</label>
                            <select name="tahun" required>
                                <option value="">-- Pilih Tahun --</option>
                                <?php for($i = date('Y'); $i >= 2010; $i--): ?>
                                    <option value="<?php echo e($i); ?>"
                                        <?php echo e(old('tahun', $d->tahun ?? '') == $i ? 'selected' : ''); ?>>
                                        <?php echo e($i); ?>

                                    </option>
                                <?php endfor; ?>

                            </select>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <div class="container-fluid px-4">
        <h1 class="mt-4">Data Laporan</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Tables</li>
        </ol>
        <div class="card mb-4">

        </div>
        <?php if(auth()->guard()->check()): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="" class="btn btn-md btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            <i class="fa-solid fa-square-plus"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>No</th>

                                <th>Bulan</th>
                                <th>Tahun</th>
                                <th>PDF</th>


                                <th>Action</th>

                            </tr>
                        </thead>
                        <tfoot>
                            <th>No</th>

                            <th>Bulan</th>
                            <th>Tahun</th>
                            <th>PDF</th>


                            <th>Action</th>
                        </tfoot>
                        <tbody>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>

                                    <td><?php echo e($d->bulan); ?></td>
                                    <td><?php echo e($d->tahun); ?></td>
                                    <td>


                                        <a href="/admin/assets/pdf/laporankas/<?php echo e($d->file_pdf); ?>" target="blank">Lihat</a>
                                    </td>




                                    <td>
                                        
                                        <a href="#" class="btn btn-sm btn-warning" data-bs-toggle="modal"
                                            data-bs-target="#editModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-pen-to-square"></i></a>

                                        <!-- ini untuk modal hapus -->
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal<?php echo e($d->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus Produk</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Apakah anda yakin akan menghapus data <?php echo e($d->bulan); ?>

                                                        <?php echo e($d->tahun); ?>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>

                                                        <form action="<?php echo e(route('laporan.destroy', $d->id)); ?>" method="POST"
                                                            style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ini batas modal hapus -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>