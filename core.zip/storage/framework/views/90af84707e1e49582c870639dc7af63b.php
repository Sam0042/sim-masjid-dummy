

<?php $__env->startSection('konten'); ?>
    <div class="container-fluid px-4">

        <h1 class="mt-4">
            Data Profil Masjid
        </h1>

        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item">
                <a href="dashboard">Dashboard</a>
            </li>

            <li class="breadcrumb-item active">
                Profil Masjid
            </li>
        </ol>

        <?php if(auth()->guard()->check()): ?>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('ketua-profil.update', $d->id)); ?>" method="POST" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    
                    <div class="card border mb-4">

                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                🕌 Sejarah Masjid
                            </h5>
                        </div>

                        <div class="card-body">

                            <label class="fw-bold mb-2">
                                Deskripsi Sejarah
                            </label>

                            <textarea name="sejarah" class="form-control mb-4" rows="10" placeholder="Masukkan sejarah masjid..."><?php echo e($d->sejarah); ?></textarea>


                            <label class="fw-bold mb-2">
                                Foto Sejarah Saat Ini
                            </label>

                            <div class="mb-4">

                                <?php if(!empty($d->foto_sejarah)): ?>
                                    <img src="<?php echo e(url('admin/assets/img/sejarah')); ?>/<?php echo e($d->foto_sejarah); ?>" alt="project-image"
                                        class=" mt-1" style="width: 250px;height:150px">
                                <?php endif; ?>

                            </div>


                            <div>

                                <label class="fw-bold mb-2">
                                    Upload Foto Baru
                                </label>

                                <input type="file" name="foto_sejarah" class="form-control">

                            </div>

                        </div>

                    </div>


                    
                    <div class="card border mb-4">

                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                🌿 Visi Masjid
                            </h5>
                        </div>

                        <div class="card-body">

                            <textarea name="visi" class="form-control" rows="2" placeholder="Masukkan visi masjid..."><?php echo e($d->visi); ?></textarea>

                        </div>

                    </div>


                    
                    <div class="card border mb-4">

                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                🎯 Misi Masjid
                            </h5>
                        </div>

                        <div class="card-body">

                            <textarea name="misi" class="form-control" rows="2" placeholder="Masukkan misi masjid..."><?php echo e($d->misi); ?></textarea>

                        </div>

                    </div>


                    
                    <div class="card border mb-4">

                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                👥 Struktur Organisasi
                            </h5>
                        </div>

                        <div class="card-body">

                            <label class="fw-bold mb-2">
                                Foto Struktur Saat Ini
                            </label>

                            <div class="mb-4">

                                <?php if(!empty($d->foto_struktur)): ?>
                                    <img src="<?php echo e(url('admin/assets/img/struktur')); ?>/<?php echo e($d->foto_struktur); ?>"
                                        alt="project-image" class=" mt-1" style="width: 250px;height:150px">
                                <?php endif; ?>

                            </div>

                            <div>

                                <label class="fw-bold mb-2">
                                    Upload Foto Baru
                                </label>

                                <input type="file" name="foto_struktur" class="form-control">

                            </div>

                        </div>

                    </div>


                    
                    <div class="card border mb-4">

                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                📍 Informasi Kontak
                            </h5>
                        </div>

                        <div class="card-body">

                            <div class="mb-3">

                                <label class="form-label fw-bold">
                                    Alamat
                                </label>

                                <textarea name="alamat" class="form-control" rows="3" placeholder="Masukkan alamat masjid..."><?php echo e($d->alamat); ?></textarea>

                            </div>

                            <div class="mb-3">

                                <label class="form-label fw-bold">
                                    Telepon
                                </label>

                                <input type="number" name="telepon" class="form-control" value="<?php echo e($d->telepon); ?>"
                                    placeholder="Masukkan nomor telepon">

                            </div>


                        </div>

                    </div>


                    
                    <div class="card border mb-4">

                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                🌐 Sosial Media
                            </h5>
                        </div>

                        <div class="card-body">



                            <div class="mb-3">

                                <label class="form-label fw-bold">
                                    Instagram
                                </label>

                                <input type="text" name="instagram" class="form-control" value="<?php echo e($d->instagram); ?>"
                                    placeholder="Masukkan link Instagram">

                            </div>



                        </div>

                    </div>


                    
                    <div class="text-end">

                        <button type="submit" class="btn btn-success px-4">

                            <i class="fa-solid fa-floppy-disk me-1"></i>

                            SIMPAN DATA

                        </button>

                    </div>

                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/profil/index.blade.php ENDPATH**/ ?>