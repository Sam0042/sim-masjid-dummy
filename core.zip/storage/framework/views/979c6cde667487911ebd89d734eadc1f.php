
<?php $__env->startSection('konten'); ?>
    <section
        style="background-image: url('/admin/image/3.jpeg'); 
           background-size: cover; 
           background-position: 50% 30%; 
           height: 200px; 
           width: 100%; 
           position: relative;
           ">

        <!-- overlay hitam transparan -->
        <div
            style="position: absolute; top:0; left:0; width:100%; height:100%; 
                background-color: rgba(0,0,0,0.8);">
        </div>

        <!-- konten teks -->
        <div class="d-flex flex-column justify-content-center align-items-center h-100"
            style="position: relative; z-index: 1;">
            <h1 class="judul-header">
                JADWAL JUMAT
            </h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item">
                    <a href="/" class="text-white fw-semibold text-decoration-none">Beranda</a>
                </li>
                <li class="breadcrumb-item active fw-semibold" id="target-bcm">Jadwal Jumat</li>
            </ol>

        </div>
    </section>


    <style>
        .section-title {
            border-left: 5px solid #198754;
            padding-left: 10px;
            margin-bottom: 10px;
        }

        .section-title h2 {
            font-weight: 700;
            margin-bottom: 0;
            color: #111;
        }

        .section-title p {
            margin-bottom: 0;
            color: #6c757d;
        }

        .lihat-lengkap {
            color: black;
            transition: color 0.3s ease;
        }

        .lihat-lengkap:hover {
            color: #198754
        }

        .card-label {
            background: rgba(32, 201, 151, 0.9);
            /* teal */
            color: #022c22;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }


        .card-jumat {
            position: relative;
            overflow: hidden;
            border-radius: 12px;
            height: 100%;
        }


        .card-jumat img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        /* GRADIENT HIJAU (MAKIN KE BAWAH MAKIN PEKAT) */

        .card-jumat::after {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, #198754, #20c997, #157347);

        }

        .card-text-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            padding: 15px;
            z-index: 2;
            color: white;
            width: 100%;
        }

        .card-jumat:hover {
            transform: scale(1.02);
            transition: 0.3s;
        }



        .pagination .page-link {
            color: #198754;
        }

        .pagination .page-link:hover {
            background-color: #198754;
            color: white;
        }

        .pagination .page-item.active .page-link {
            background-color: #198754;
            border-color: #198754;
            color: white
        }

        .jadwal-card-content {
            position: absolute;
            inset: 0;
            z-index: 2;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;

            color: white;
        }

        .tanggal-jumat {
            text-align: center;
            font-size: 18px;
            font-weight: 700;
            line-height: 1.5;
            margin-top: 1px;
            margin-bottom: 0.5rem;
        }

        .petugas-wrapper {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .petugas-item {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .petugas-label {
            font-size: 0.7rem;
            color: #d1fae5;
            font-weight: 600;
            margin-bottom: 1px;
        }

        .petugas-nama {
            font-size: 1rem;
            font-weight: 500;
            color: white;
        }
    </style>

    <div class="container py-4">

        
        <div class="d-flex justify-content-between align-items-center mb-2">

            <div class="section-title">
                <h2>Jadwal Khotib dan Muazin Jumat</h2>
            </div>

        </div>

        
        <div class="row g-3">

            

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        
                        <table id="datatablesSimple" class="table table-bordered table-striped align-middle">
                            
                            <thead class="table-dark">
                                <tr>

                                    <th>Tanggal</th>
                                    <th>Khotib/Imam</th>
                                    <th>Muazin</th>
                                    <?php if(auth()->guard()->check()): ?>
                                        <th class="text-center" style="width: 15%">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            
                            <thead class="table-dark">
                                <tr>

                                    <th>Tanggal</th>
                                    <th>Khotib/Imam</th>
                                    <th>Muazin</th>
                                    <?php if(auth()->guard()->check()): ?>
                                        <th class="text-center">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e(\Carbon\Carbon::parse($d->tanggal)->translatedFormat('d F Y')); ?></td>
                                        <td><?php echo e($d->khotib); ?></td>
                                        <td><?php echo e($d->muazin); ?></td>

                                        <?php if(auth()->guard()->check()): ?>
                                            <td class="text-center">
                                                <a href="#" class="btn btn-sm btn-warning" data-bs-toggle="modal"
                                                    data-bs-target="#editModal<?php echo e($d->id); ?>">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>

                                                <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                                    data-bs-target="#exampleModal<?php echo e($d->id); ?>">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>

                                                <div class="modal fade apus text-start" id="exampleModal<?php echo e($d->id); ?>"
                                                    tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus data
                                                                </h1>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                    aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Apakah anda yakin akan menghapus data <?php echo e($d->tanggal); ?>?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Close</button>

                                                                <form action="<?php echo e(route('khotibMuazin.destroy', $d->id)); ?>"
                                                                    method="POST" style="display:inline;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit"
                                                                        class="btn btn-danger">Delete</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <script>
                window.addEventListener('DOMContentLoaded', event => {
                    const datatablesSimple = document.getElementById('datatablesSimple');
                    if (datatablesSimple) {
                        new simpleDatatables.DataTable(datatablesSimple, {
                            // Menentukan pilihan jumlah baris dan default tampilan pertama (5 baris)
                            perPageSelect: [5, 10, 15, 20, 25],
                            perPage: 5,
                            labels: {
                                placeholder: "Cari...",
                                perPage: "baris per halaman",
                                noRows: "Tidak ada data ditemukan",
                                info: "Menampilkan {start} sampai {end} dari {rows} baris",
                            }
                        });
                    }
                });
            </script>
        </div>


        

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/front/jumat/index.blade.php ENDPATH**/ ?>