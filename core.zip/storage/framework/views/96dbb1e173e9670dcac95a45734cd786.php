<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>