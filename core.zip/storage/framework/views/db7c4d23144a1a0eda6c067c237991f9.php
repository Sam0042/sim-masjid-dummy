<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-body-tertiary sticky-top">
    <!-- Container wrapper -->
    <div class="container-fluid">
        <!-- Toggle button -->
        <button data-mdb-collapse-init class="navbar-toggler" type="button" data-mdb-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Collapsible wrapper -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Navbar brand -->
            <a class="navbar-brand mt-2 mt-lg-0 ms-3" href="#">
                <img src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp" height="15"
                    alt="MDB Logo" loading="lazy" />
            </a>
            <!-- Left links -->
            <ul class="navbar-nav  mb-2 mb-lg-0 mx-auto d-flex justify-content-between gap-3">
                <li class="nav-item">
                    <a class="nav-link" href="/">Beranda</a>
                </li>
                <!-- Navbar dropdown -->
                <li class="nav-item dropdown">
                    <a data-mdb-dropdown-init class="nav-link dropdown-toggle" href="#" id="navbarDropdown"
                        role="button" aria-expanded="false">
                        Informasi
                    </a>
                    <!-- Dropdown menu -->
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Berita</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/program">Program</a>
                        </li>

                    </ul>
                </li>

                <!-- Navbar dropdown -->
                <li class="nav-item dropdown">
                    <a data-mdb-dropdown-init class="nav-link dropdown-toggle" href="#" id="navbarDropdown"
                        role="button" aria-expanded="false">
                        Jadwal
                    </a>
                    <!-- Dropdown menu -->
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li>
                            <a class="dropdown-item" href="#">Waktu Sholat</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#">Imam 5 Waktu</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#">Imam Jum'at</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    
                    <a class="nav-link" href="/galeri">Galeri</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Donasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Tentang Kami</a>
                </li>
            </ul>
            <!-- Left links -->
        </div>
        <!-- Collapsible wrapper -->

        <!-- Right elements -->
        
        <div class="d-flex align-items-center gap-2 me-3">
            <a href="/admin" class="btn btn-primary">Masuk</a>
            <a href="#" class="btn btn-success">Daftar</a>
        </div>
        <!-- Right elements -->
    </div>
    <!-- Container wrapper -->
</nav>
<!-- Navbar -->
<?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/front/layouts/navbar.blade.php ENDPATH**/ ?>