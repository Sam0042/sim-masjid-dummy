<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Roudhotul Jannah Web</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('admin')); ?>/css/styles.css" rel="stylesheet" />
    
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="/">Roudhotul Jannah</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i
                class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        
        <!-- Navbar-->
        
        <ul class="navbar-nav ms-auto me-3 me-lg-4">

            <!-- logic login register -->
            <style>
                .hover-effect {
                    color: #ff5667;
                }

                .logreg {
                    color: rgb(188, 188, 188);
                }

                .welcome {
                    margin-right: 5px;
                }

                .hover-effect:hover,
                .hover-effect:hover i,
                .logreg:hover {
                    color: white;
                }
            </style>
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                    <li class="nav-item ">
                        <a class="nav-link logreg" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                <?php endif; ?>

                
            <?php else: ?>
                <li class="nav-item welcome">
                    <span class="nav-link text-light ">Selamat datang, <?php echo e(Auth::user()->name); ?>!</span>
                </li>
                <li class="nav-item">
                    <span class="nav-link " style="color: rgb(159, 159, 159)">|</span>
                </li>
                <li class="nav-item">
                    <a class="nav-link hover-effect" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fa-solid fa-right-from-bracket"></i> <?php echo e(__('Logout')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>

            <?php endif; ?>
        </ul>

    </nav>
<?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>