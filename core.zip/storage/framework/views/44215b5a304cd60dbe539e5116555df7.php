</main>
<style>
    .footer-modern {
        margin-top: 100px;
        padding-bottom: 30px;
        padding-top: 2rem;
        background: #212529;
    }

    .footer-logo {
        width: 70px;
        margin-bottom: 20px;
    }

    .footer-title {
        font-size: 34px;
        font-weight: 800;
        color: #ffffff;
        margin-bottom: 14px;
    }

    .footer-desc {
        max-width: 650px;
        margin: auto;
        color: #cbd5e1;
        line-height: 1.8;
    }

    .footer-contact {
        margin-top: 35px;
        color: #f8f9fa;
        font-weight: 600;
    }

    .footer-contact div {
        margin-bottom: 12px;
    }

    .footer-contact i {
        color: #20c997;
        margin-right: 8px;
    }

    .footer-bottom {
        margin-top: 45px;
        padding-top: 25px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        color: #adb5bd;
        font-size: 14px;
    }

    @media (max-width: 991px) {

        .footer-modern {
            padding-top: 30px;
        }

        .footer-title {
            font-size: 28px;
        }

        .footer-desc {
            font-size: 15px;
        }
    }
</style>




<footer class="footer-modern">

    <div class="container text-center">

        <?php if(auth()->guard()->guest()): ?>
            <img src="<?php echo e(asset('front/assets/img/logo-masjid.png')); ?>" class="footer-logo" alt="Logo">

            <h2 class="footer-title">
                Masjid Jami’ Roudhotul Jannah
            </h2>

            <p class="footer-desc">
                Website resmi masjid sebagai pusat informasi kegiatan,
                agenda dakwah, layanan jamaah, dokumentasi,
                dan media publikasi masjid.
            </p>

            <div class="footer-contact">

                <div>
                    <i class="fa-solid fa-location-dot"></i>
                    <?php echo e($profil->alamat); ?>

                </div>

                <div>
                    <i class="fa-brands fa-instagram"></i>
                    <?php echo e($profil->instagram); ?>

                </div>

                <div>
                    <i class="fa-solid fa-phone"></i>
                    <?php echo e($profil->telepon); ?>

                </div>

            </div>

            <div class="footer-bottom">

                © <?php echo e(date('Y')); ?>

                Masjid Jami’ Roudhotul Jannah.
                All rights reserved.

            </div>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <img src="<?php echo e(asset('front/assets/img/logo-masjid.png')); ?>" class="footer-logo" alt="Logo">

            <h2 class="footer-title">
                Masjid Jami’ Roudhotul Jannah
            </h2>
            <div class="footer-bottom" style="border-top: none">

                © <?php echo e(date('Y')); ?>

                Masjid Jami’ Roudhotul Jannah.
                All rights reserved.

            </div>
        <?php endif; ?>

    </div>

</footer>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
</script>
<script src="<?php echo e(asset('admin')); ?>/js/scripts.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"
    crossorigin="anonymous"></script>
<script src="<?php echo e(asset('admin')); ?>/js/datatables-simple-demo.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>