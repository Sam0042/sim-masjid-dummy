

<?php $__env->startSection('konten'); ?>
    <div class="container-fluid px-4">

        <h1 class="mt-4">
            Data Saldo Awal
        </h1>

        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item">
                <a href="dashboard">Dashboard</a>
            </li>

            <li class="breadcrumb-item active">
                Saldo Awal
            </li>
        </ol>

        <?php if(auth()->guard()->check()): ?>


            <form action="<?php echo e(route('saldo-awal.update', $data->id)); ?>" method="POST" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="card border mb-4">

                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            Saldo Awal
                        </h5>
                    </div>

                    <div class="card-body">
                        <div class="mb-3">
                            <input type="number" name="nominal" class="form-control" value="<?php echo e($data->nominal); ?>" required
                                placeholder="Masukkan nominal">
                            
                        </div>
                        

                    </div>

                </div>



                
                <div class="text-end">

                    <button type="submit" class="btn btn-success px-4">

                        <i class="fa-solid fa-floppy-disk me-1"></i>

                        SIMPAN DATA

                    </button>

                </div>

            </form>

        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/saldoAwal/index.blade.php ENDPATH**/ ?>