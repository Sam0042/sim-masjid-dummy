<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Laporan Keuangan</title>
    <style>
        body {
            font-family: sans-serif;
            font-size: 11px;
        }

        .table-wrapper {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }

        .judul-laporan {
            text-align: center;
            margin-bottom: 15px;
        }

        .judul-laporan b {
            display: block;
        }

        table.table-keuangan {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table.table-keuangan th,
        table.table-keuangan td {
            border: 1px solid #000;
            padding: 4px;
            text-align: center;
        }

        table.table-keuangan thead th {
            background-color: #f2f2f2;
        }

        .text-left {
            text-align: left !important;
        }

        .bg-blue {
            background-color: #e0f2fe;
        }

        .bg-light {
            background-color: #f8f9fa;
        }

        .bg-green {
            background-color: #e9fbe9;
        }

        .bg-red {
            background-color: #fdeeee;
        }

        .bg-dark-blue {
            background-color: #dbeafe;
        }
    </style>
</head>

<body>

    <?php $__currentLoopData = $dataByMonthFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaBulan => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $dates = $data->groupBy('tanggal');
            $dateKeys = $dates->keys();
            $saldoAwal = $saldoAwalBulan; // Pastikan variabel ini tersedia
        ?>

        <div class="table-wrapper">
            <div class="judul-laporan">
                <b>Masjid Roudhotul Jannah</b>
                <b>Laporan Keuangan</b>
                <b>Kas Operasional</b>
                <b><?php echo e($namaBulan); ?></b>
            </div>

            <table class="table-keuangan">
                <thead>
                    <tr>
                        <th rowspan="2">Keterangan</th>
                        <th rowspan="2">Saldo Awal</th>
                        <th colspan="<?php echo e($dateKeys->count()); ?>">Tanggal</th>
                        <th rowspan="2">Jumlah</th>
                    </tr>
                    <tr>
                        <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e(\Carbon\Carbon::parse($date)->format('d-M-y')); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <!-- SALDO AWAL -->
                    <tr class="bg-blue" style="font-weight:bold;">
                        <td>Saldo Awal</td>
                        <td><?php echo e(number_format($saldoAwal, 0, ',', '.')); ?></td>
                        <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td></td>
                    </tr>

                    <!-- PENERIMAAN -->
                    <tr class="bg-light" style="font-weight:bold;">
                        <td colspan="<?php echo e($dateKeys->count() + 3); ?>" class="text-left">Penerimaan</td>
                    </tr>
                    <?php
                        $totalPenerimaanPerTanggal = array_fill_keys($dateKeys->toArray(), 0);
                        $grandTotalPenerimaan = 0;
                        $penerimaanUnik = $data->where('jenis', 'penerimaan')->unique('keterangan');
                    ?>
                    <?php $__currentLoopData = $penerimaanUnik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-left"><?php echo e($item->keterangan); ?></td>
                            <td></td>
                            <?php $totalRow = 0; ?>
                            <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $amount = $dates[$date]->where('keterangan', $item->keterangan)->sum('nominal');
                                    $totalRow += $amount;
                                    $totalPenerimaanPerTanggal[$date] += $amount;
                                ?>
                                <td><?php echo e(number_format($amount, 0, ',', '.')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalRow, 0, ',', '.')); ?></td>
                        </tr>
                        <?php $grandTotalPenerimaan += $totalRow; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-green" style="font-weight:bold;">
                        <td>Total Penerimaan</td>
                        <td></td>
                        <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalPenerimaanPerTanggal[$date], 0, ',', '.')); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e(number_format($grandTotalPenerimaan, 0, ',', '.')); ?></td>
                    </tr>

                    <!-- PENGELUARAN -->
                    <tr class="bg-light" style="font-weight:bold;">
                        <td colspan="<?php echo e($dateKeys->count() + 3); ?>" class="text-left">Pengeluaran</td>
                    </tr>
                    <?php
                        $totalPengeluaranPerTanggal = array_fill_keys($dateKeys->toArray(), 0);
                        $grandTotalPengeluaran = 0;
                        $pengeluaranUnik = $data->where('jenis', 'pengeluaran')->unique('keterangan');
                    ?>
                    <?php $__currentLoopData = $pengeluaranUnik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-left"><?php echo e($item->keterangan); ?></td>
                            <td></td>
                            <?php $totalRow = 0; ?>
                            <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $amount = $dates[$date]->where('keterangan', $item->keterangan)->sum('nominal');
                                    $totalRow += $amount;
                                    $totalPengeluaranPerTanggal[$date] += $amount;
                                ?>
                                <td><?php echo e(number_format($amount, 0, ',', '.')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalRow, 0, ',', '.')); ?></td>
                        </tr>
                        <?php $grandTotalPengeluaran += $totalRow; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-red" style="font-weight:bold;">
                        <td>Total Pengeluaran</td>
                        <td></td>
                        <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalPengeluaranPerTanggal[$date], 0, ',', '.')); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e(number_format($grandTotalPengeluaran, 0, ',', '.')); ?></td>
                    </tr>

                    <!-- SALDO KAS -->
                    <tr class="bg-dark-blue" style="font-weight:bold;">
                        <td>Saldo Kas Operasional</td>
                        <td><?php echo e(number_format($saldoAwal, 0, ',', '.')); ?></td>
                        <?php $saldoBerjalan = $saldoAwal; ?>
                        <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $saldoBerjalan += ($totalPenerimaanPerTanggal[$date] - $totalPengeluaranPerTanggal[$date]); ?>
                            <td><?php echo e(number_format($saldoBerjalan, 0, ',', '.')); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e(number_format($saldoBerjalan, 0, ',', '.')); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/kasOperasional/pdf.blade.php ENDPATH**/ ?>