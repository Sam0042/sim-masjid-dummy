
<?php $__env->startSection('konten'); ?>
    <br>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Program Masjid</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="/">Beranda</a></li>
            <li class="breadcrumb-item active">Program</li>
        </ol>

    </div>
    <?php if($data->isEmpty()): ?>
        <p style="text-align: center;color:grey">Tidak Ada Program yang Tersedia</p>
    <?php else: ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3" style="max-width: 90%;margin:0 auto;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="<?php echo e(url('admin/assets/img')); ?>/<?php echo e($d->foto); ?>" class="img-fluid rounded-start"
                            alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h4 class="card-title"><b><?php echo e($d->nama); ?></b></h4>
                            <p style="color:grey" class="card-text"><?php echo e($d->deskripsi); ?></p>
                            <p class="card-text">Dari: <span style="color: green"><?php echo e($d->tanggal_mulai); ?></span></p>
                            <p class="card-text">Hingga: <span style="color: red"><?php echo e($d->tanggal_selesai); ?></span></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/front/program/index.blade.php ENDPATH**/ ?>