
<?php $__env->startSection('konten'); ?>
    <!-- Modal -->
    <div style="height:90%; margin-top: 3.5rem;"class="modal fade" id="exampleModal" tabindex="-1"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Jadwal Khotib dan Muazin</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('khotibMuazin.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="tanggal" class="form-label">Tanggal</label>
                        <input required type="date" class="form-control" name="tanggal" id="tanggalInput"
                            aria-describedby="dateHelp" placeholder="Pilih Tanggal Jumat"
                            min="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>">
                        <br>
                        <label for="khotib" class="form-label">Nama Khotib</label>
                        <input type="text" class="form-control" name="khotib" id="exampleInputEmail1"
                            aria-describedby="emailHelp" placeholder="Masukkan Nama Khotib" required>
                        <br>
                        <label for="no_hp" class="form-label">Nomor HP</label>
                        <input type="number" class="form-control" name="no_hp" id="exampleInputEmail1"
                            aria-describedby="emailHelp" placeholder="Masukkan Nomor HP Khotib">
                        <br>
                        <label for="muazin" class="form-label">Nama Muazin</label>
                        <input type="text" class="form-control" name="muazin" id="exampleInputEmail1"
                            aria-describedby="emailHelp" placeholder="Masukkan Nama Muazin" required>
                        <br>



                        <script>
                            // Daftar tanggal yang sudah dipilih oleh imam lain (misalnya ini diambil dari database)
                            const takenDates = <?php echo json_encode($takenDates, 15, 512) ?>; // Mendapatkan tanggal yang sudah terambil dari backend

                            document.getElementById('tanggalInput').addEventListener('change', function() {
                                const inputDate = new Date(this.value);
                                const dayOfWeek = inputDate.getUTCDay();

                                // Validasi agar hanya tanggal Jumat yang bisa dipilih
                                if (dayOfWeek !== 5) {
                                    alert("Silakan pilih tanggal yang jatuh pada hari Jumat.");
                                    this.value = ""; // Mengosongkan input jika bukan Jumat
                                }

                                // Validasi agar hanya tanggal yang lebih besar atau sama dengan hari ini yang bisa dipilih
                                const today = new Date();
                                if (inputDate < today) {
                                    alert("Silakan pilih tanggal yang akan datang.");
                                    this.value = ""; // Mengosongkan input jika tanggal yang dipilih lebih kecil dari hari ini
                                }

                                // Validasi agar tanggal yang dipilih tidak bentrok dengan imam lain
                                if (takenDates.includes(this.value)) {
                                    alert("Tanggal ini sudah dipilih sebelumnya. Silakan pilih tanggal lain.");
                                    this.value = ""; // Mengosongkan input jika tanggal sudah terambil
                                }
                            });
                        </script>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ini batas modal -->

    <!-- Modal -->

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal -->
        <div style="height:90%; margin-top: 3.5rem;"class="modal fade" id="editModal<?php echo e($d->id); ?>" tabindex="-1"
            aria-labelledby="editModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Edit Jadwal</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('khotibMuazin.update', $d->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <label for="tanggal" class="form-label">Tanggal</label>
                            <input required type="date" class="form-control" name="tanggal"
                                id="tanggalInput<?php echo e($d->id); ?>" value="<?php echo e($d->tanggal); ?>"
                                min="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>">
                            <br>
                            <label for="khotib" class="form-label">Nama Khotib</label>
                            <input type="text" class="form-control" name="khotib" id="exampleInputEmail1"
                                aria-describedby="emailHelp" placeholder="Masukkan Nama Khotib" value="<?php echo e($d->khotib); ?>">
                            <br>
                            <label for="no_hp" class="form-label">Nomor HP Khotib</label>
                            <input type="number" class="form-control" name="no_hp" id="exampleInputEmail1"
                                aria-describedby="emailHelp" placeholder="Masukkan Nomor HP Khotib"
                                value="<?php echo e($d->no_hp); ?>">
                            <br>
                            <label for="muazin" class="form-label">Nama Muazin</label>
                            <input type="text" class="form-control" name="muazin" id="exampleInputEmail1"
                                aria-describedby="emailHelp" placeholder="Masukkan Nama Muazin"
                                value="<?php echo e($d->muazin); ?>">
                            <br>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- End of Modal -->

        <script>
            // const takenDates = <?php echo json_encode($takenDates, 15, 512) ?>;
            // Menggunakan event listener ketika modal ditampilkan
            document.getElementById('editModal<?php echo e($d->id); ?>').addEventListener('shown.bs.modal', function() {
                const dateInput = document.getElementById('tanggalInput<?php echo e($d->id); ?>');

                // Menambahkan event listener pada input date
                dateInput.addEventListener('change', function() {
                    const inputDate = new Date(this.value);
                    const dayOfWeek = inputDate.getUTCDay();

                    if (dayOfWeek !== 5) { // Mengecek apakah hari Jumat
                        alert("Silakan pilih tanggal yang jatuh pada hari Jumat.");
                        this.value = "";
                    }

                    const today = new Date();
                    if (inputDate < today) { // Mengecek apakah tanggal yang dipilih lebih besar dari hari ini
                        alert("Silakan pilih tanggal yang akan datang.");
                        this.value = "";
                    }

                    // Validasi agar tanggal yang dipilih tidak bentrok dengan imam lain
                    if (takenDates.includes(this.value)) {
                        alert("Tanggal ini sudah dipilih oleh imam lain. Silakan pilih tanggal lain.");
                        this.value = ""; // Mengosongkan input jika tanggal sudah terambil
                    }

                });
            });
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- ini batas modal -->

    <div class="container-fluid px-4">
        <h1 class="mt-4">Data Khotib dan Muazin Jumat</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Tables</li>
        </ol>
        <div class="card mb-4">

        </div>
        <div class="card mb-4">
            <div class="card-header">

                <?php if(auth()->guard()->check()): ?>
                    <a href="" class="btn btn-md btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <i class="fa-solid fa-square-plus"></i>
                    </a>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <h5>Jadwal Imam Jumat</h5>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Khotib/Imam</th>
                            <th>Nomor Hp</th>
                            <th>Muazin</th>
                            <?php if(auth()->guard()->check()): ?>
                                <th>Action</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tfoot>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Khotib/Imam</th>
                        <th>Nomor Hp</th>
                        <th>Muazin</th>
                        <?php if(auth()->guard()->check()): ?>
                            <th>Action</th>
                        <?php endif; ?>
                    </tfoot>
                    <tbody>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($d->tanggal); ?></td>
                                <td><?php echo e($d->khotib); ?></td>
                                </td>
                                <td><?php echo e($d->no_hp); ?></td>
                                <td><?php echo e($d->muazin); ?></td>
                                </td>

                                <?php if(auth()->guard()->check()): ?>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-warning" data-bs-toggle="modal"
                                            data-bs-target="#editModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-pen-to-square"></i></a>

                                        <!-- ini untuk modal hapus -->
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade apus" id="exampleModal<?php echo e($d->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus data</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Apakah anda yakin akan menghapus data <?php echo e($d->tanggal); ?>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>

                                                        <form action="<?php echo e(route('khotibMuazin.destroy', $d->id)); ?>"
                                                            method="POST" style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ini batas modal hapus -->
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/khotibMuazin/index.blade.php ENDPATH**/ ?>