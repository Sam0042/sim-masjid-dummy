<?php $__env->startSection('konten'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-1">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
        <div class="row">


            
            <?php if(Auth::check() && Auth::user()->role === 'ubudiyah'): ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-success text-white mb-4">
                        <div class="card-body">Data Khotib dan Muazin : <?php echo e($khotibMuazin); ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="<?php echo e(route('khotibMuazin.index')); ?>">
                                View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-danger text-white mb-4">
                        <div class="card-body">Data Agenda : <?php echo e($program); ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="<?php echo e(route('program.index')); ?>">
                                View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-info text-white mb-4">
                        <div class="card-body">Data Galeri : <?php echo e($galeri); ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="<?php echo e(route('galeri.index')); ?>">
                                View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            
            <?php if(Auth::check() && Auth::user()->role === 'ketua'): ?>
                

                <form method="GET" class="row g-3 align-items-end mb-3">

                    
                    <div class="col-md-3">
                        <select name="tahun" onchange="this.form.submit()" class="form-control">

                            <option value="" disabled <?php echo e(request('tahun') ? '' : 'selected'); ?>>
                                Pilih Tahun
                            </option>

                            <?php $__currentLoopData = $listTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tahun); ?>" <?php echo e($tahun == $tahunAktif ? 'selected' : ''); ?>>
                                    <?php echo e($tahun); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div class="col-md-3">
                        <select name="bulan" onchange="this.form.submit()" class="form-control">

                            <option value="" disabled <?php echo e(request('bulan') ? '' : 'selected'); ?>>
                                Pilih Bulan
                            </option>

                            <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($i == $bulanAktif ? 'selected' : ''); ?>>
                                    <?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                </form>

                <div class="row">

                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                Saldo Bulanan <?php echo e($tahunAktif); ?>

                            </div>
                            <div class="card-body">
                                <canvas id="barChart"></canvas>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>Saldo Harian</span>



                            </div>
                            <div class="card-body">
                                <canvas id="areaChart"></canvas>
                            </div>
                        </div>
                    </div>

                </div>

                
                <script>
                    var labels = <?php echo json_encode($labels); ?>;
                    var dataBulanan = <?php echo json_encode($dataBulanan); ?>;

                    var labelsHarian = <?php echo json_encode($labelsHarian); ?>;
                    var dataHarian = <?php echo json_encode($dataHarian); ?>;
                </script>

                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

                <script>
                    // =======================
                    // FORMAT BULAN
                    // =======================
                    const bulan = ["", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
                        "Jul", "Agu", "Sep", "Okt", "Nov", "Des"
                    ];

                    labels = labels.map(b => bulan[b]);

                    // =======================
                    // BAR CHART (KIRI)
                    // =======================
                    new Chart(document.getElementById("barChart"), {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: "Saldo Bulanan <?php echo e($tahunAktif); ?>",
                                data: dataBulanan,
                                backgroundColor: dataBulanan.map(v => v >= 0 ? 'green' : 'red')
                            }]
                        }
                    });

                    // =======================
                    // AREA CHART (KANAN)
                    // =======================
                    new Chart(document.getElementById("areaChart"), {
                        type: 'line',
                        data: {
                            labels: labelsHarian,
                            datasets: [{
                                label: "Saldo Harian",
                                data: dataHarian,
                                fill: true,
                                backgroundColor: "rgba(2,117,216,0.2)",
                                borderColor: "rgba(2,117,216,1)",
                                tension: 0.3
                            }]
                        }
                    });
                </script>
            <?php endif; ?>



            
            <?php if(Auth::check() && Auth::user()->role === 'bendahara'): ?>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-warning text-white mb-4">
                        <div class="card-body">Data Keterangan Kas : <?php echo e($ketKas); ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="<?php echo e(route('keterangan_kas.index')); ?>">
                                View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6">
                    <div class="card bg-success text-white mb-4">
                        <div class="card-body">Data Final : <?php echo e($kas); ?></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="<?php echo e(route('kas_operasional.index')); ?>">
                                View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>

                <form method="GET" class="row g-3 align-items-end mb-3">

                    
                    <div class="col-md-3">
                        <select name="tahun" onchange="this.form.submit()" class="form-control">

                            <option value="" disabled <?php echo e(request('tahun') ? '' : 'selected'); ?>>
                                Pilih Tahun
                            </option>

                            <?php $__currentLoopData = $listTahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tahun); ?>" <?php echo e($tahun == $tahunAktif ? 'selected' : ''); ?>>
                                    <?php echo e($tahun); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div class="col-md-3">
                        <select name="bulan" onchange="this.form.submit()" class="form-control">

                            <option value="" disabled <?php echo e(request('bulan') ? '' : 'selected'); ?>>
                                Pilih Bulan
                            </option>

                            <?php for($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($i == $bulanAktif ? 'selected' : ''); ?>>
                                    <?php echo e(DateTime::createFromFormat('!m', $i)->format('F')); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                </form>

                <div class="row">

                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                Saldo Bulanan <?php echo e($tahunAktif); ?>

                            </div>
                            <div class="card-body">
                                <canvas id="barChart"></canvas>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span>Saldo Harian</span>



                            </div>
                            <div class="card-body">
                                <canvas id="areaChart"></canvas>
                            </div>
                        </div>
                    </div>

                </div>

                
                <script>
                    var labels = <?php echo json_encode($labels); ?>;
                    var dataBulanan = <?php echo json_encode($dataBulanan); ?>;

                    var labelsHarian = <?php echo json_encode($labelsHarian); ?>;
                    var dataHarian = <?php echo json_encode($dataHarian); ?>;
                </script>

                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

                <script>
                    // =======================
                    // FORMAT BULAN
                    // =======================
                    const bulan = ["", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
                        "Jul", "Agu", "Sep", "Okt", "Nov", "Des"
                    ];

                    labels = labels.map(b => bulan[b]);

                    // =======================
                    // BAR CHART (KIRI)
                    // =======================
                    new Chart(document.getElementById("barChart"), {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: "Saldo Bulanan <?php echo e($tahunAktif); ?>",
                                data: dataBulanan,
                                backgroundColor: dataBulanan.map(v => v >= 0 ? 'green' : 'red')
                            }]
                        }
                    });

                    // =======================
                    // AREA CHART (KANAN)
                    // =======================
                    new Chart(document.getElementById("areaChart"), {
                        type: 'line',
                        data: {
                            labels: labelsHarian,
                            datasets: [{
                                label: "Saldo Harian",
                                data: dataHarian,
                                fill: true,
                                backgroundColor: "rgba(2,117,216,0.2)",
                                borderColor: "rgba(2,117,216,1)",
                                tension: 0.3
                            }]
                        }
                    });
                </script>
            <?php endif; ?>

            
            <?php if(Auth::check() && Auth::user()->role === 'sekretaris'): ?>
                <h1>halloo</h1>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>