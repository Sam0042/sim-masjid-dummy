

<?php $__env->startSection('content'); ?>
    <img src="https://storage.nu.or.id/storage/post/16_9/big/whatsapp-image-2022-02-06-at-174839_1644144576.jpeg"
        alt="" class="w-100" style="height: 90%;object-fit:cover">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/front/beranda.blade.php ENDPATH**/ ?>