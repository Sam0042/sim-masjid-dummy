<style>
    /* mini hp */
    .judul-header {
        color: white;
        font-weight: bold;
        text-align: center;
        margin-bottom: 1.5rem;
    }

    #target-bcm {
        color: #20c997;
    }

    #jml-foto {
        position: absolute;
        right: 12px;
        transform: translateY(-100%);
        background: rgba(0, 0, 0, 0.441);
        color: #20c997;
        padding: 6px 12px;
        border-radius: 30px;
        font-size: 1.3rem;
        font-weight: 600;
        backdrop-filter: blur(10px);
    }

    #exampleModal,
    #editModal,
    .apus {
        margin-top: 3.5rem;
    }

    /* tablet */
    @media (min-width: 768px) {
        .judul-header {
            font-size: 2.4rem;
        }

        /* HAPUS height: 300px dari #konten agar tingginya otomatis memanjang */
        #konten {
            height: auto;
        }
    }

    /* laptop */
    @media (min-width: 1024px) {
        /* isi */
    }
</style>

<?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<div style="min-height: 60vh;">
    <?php echo $__env->yieldContent('konten'); ?>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>