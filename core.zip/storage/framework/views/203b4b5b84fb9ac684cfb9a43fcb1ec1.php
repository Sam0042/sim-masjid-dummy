<br>

<div>
    <?php $__currentLoopData = $dataByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <b>Masjid Roudhotul Jannah</b><br>
        <b>Laporan Keuangan</b><br>
        <b>Kas Operasional</b><br>
        <b><?php echo e($month); ?></b>
        <br><br>

        <?php
            $dates = $data->groupBy('tanggal');
            $dateKeys = $dates->keys();
            $saldoAwal = $data->where('keterangan', 'Saldo Awal')->sum('nominal');
        ?>

        <table style="width:100%; border-collapse: collapse; text-align:center;" border="1">
            <thead style="background:#f3f4f6;">
                <tr>
                    <th rowspan="2">Keterangan</th>
                    <th colspan="<?php echo e($dates->count()); ?>">Tanggal</th>
                    <th rowspan="2">Jumlah</th>
                </tr>
                <tr>
                    <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(\Carbon\Carbon::parse($date)->format('d-M-Y')); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>

                
                <tr style="font-weight:bold; background:#e0f2fe;">
                    <td>Saldo Awal</td>
                    <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $saldoTanggal = $dates[$date]->where('keterangan', 'Saldo Awal')->sum('nominal');
                        ?>
                        <td><?php echo e(number_format($saldoTanggal, 0, ',', '.')); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e(number_format($saldoAwal, 0, ',', '.')); ?></td>
                </tr>

                
                <tr>
                    <td colspan="<?php echo e($dates->count() + 2); ?>" style="background:#fff; height:10px;"></td>
                </tr>

                
                <tr style="font-weight:bold;">
                    <td colspan="<?php echo e($dates->count() + 2); ?>" style="text-align:left;">Penerimaan</td>
                </tr>

                <?php
                    $totalPenerimaanPerTanggal = array_fill_keys($dateKeys->toArray(), 0);
                    $grandTotalPenerimaan = 0;
                ?>

                <?php $__currentLoopData = $penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggal => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $items->unique('keterangan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->keterangan); ?></td>
                            <?php $totalRow = 0; ?>
                            <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $amount = $dates[$date]->where('keterangan', $item->keterangan)->sum('nominal');
                                    $totalRow += $amount;
                                    $totalPenerimaanPerTanggal[$date] += $amount;
                                ?>
                                <td><?php echo e(number_format($amount, 0, ',', '.')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalRow, 0, ',', '.')); ?></td>
                            <?php $grandTotalPenerimaan += $totalRow; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <tr style="font-weight: bold; background-color: #e9fbe9;">
                    <td>Total Penerimaan</td>
                    <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e(number_format($totalPenerimaanPerTanggal[$date], 0, ',', '.')); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e(number_format($grandTotalPenerimaan, 0, ',', '.')); ?></td>
                </tr>

                
                <tr>
                    <td colspan="<?php echo e($dates->count() + 2); ?>" style="background:#fff; height:10px;"></td>
                </tr>

                
                <tr style="font-weight:bold;">
                    <td colspan="<?php echo e($dates->count() + 2); ?>" style="text-align:left;">Pengeluaran</td>
                </tr>

                <?php
                    $totalPengeluaranPerTanggal = array_fill_keys($dateKeys->toArray(), 0);
                    $grandTotalPengeluaran = 0;
                ?>

                <?php $__currentLoopData = $pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggal => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $items->unique('keterangan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->keterangan); ?></td>
                            <?php $totalRow = 0; ?>
                            <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $amount = $dates[$date]->where('keterangan', $item->keterangan)->sum('nominal');
                                    $totalRow += $amount;
                                    $totalPengeluaranPerTanggal[$date] += $amount;
                                ?>
                                <td><?php echo e(number_format($amount, 0, ',', '.')); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format($totalRow, 0, ',', '.')); ?></td>
                            <?php $grandTotalPengeluaran += $totalRow; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <tr style="font-weight: bold; background-color: #fdeeee;">
                    <td>Total Pengeluaran</td>
                    <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e(number_format($totalPengeluaranPerTanggal[$date], 0, ',', '.')); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e(number_format($grandTotalPengeluaran, 0, ',', '.')); ?></td>
                </tr>

                
                <tr>
                    <td colspan="<?php echo e($dates->count() + 2); ?>" style="background:#fff; height:10px;"></td>
                </tr>

                
                

                <?php
                    $saldoBerjalan = $saldoAwal;
                ?>

                <tr style="font-weight:bold;background:#dbeafe;">
                    <td>Saldo Kas Operasional</td>
                    <?php $__currentLoopData = $dateKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $penerimaan = $totalPenerimaanPerTanggal[$date] ?? 0;
                            $pengeluaran = $totalPengeluaranPerTanggal[$date] ?? 0;

                            // Tambahkan saldo awal hanya di awal (index pertama)
                            if ($index == 0) {
                                $saldoBerjalan = $saldoAwal + $penerimaan - $pengeluaran;
                            } else {
                                $saldoBerjalan += $penerimaan - $pengeluaran;
                            }
                        ?>
                        <td><?php echo e(number_format($saldoBerjalan, 0, ',', '.')); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e(number_format($saldoBerjalan, 0, ',', '.')); ?></td>
                </tr>


            </tbody>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\fullstack-web\hisyam\sim-masjid\resources\views/admin/kasOperasional/printByMonth.blade.php ENDPATH**/ ?>