
<?php $__env->startSection('konten'); ?>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Data Kas Operasional</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('kas_operasional.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="tanggal" class="form-label">Tanggal</label>
                        <input required type="date" class="form-control" name="tanggal" id="tanggalInput"
                            aria-describedby="dateHelp">
                        <br>
                        <label for="keterangan_id" class="form-label">Nama Keterangan</label>
                        <select required name="keterangan_id" id="select" class="form-control">
                            <option value="" disabled selected>Pilih Keterangan</option>
                            <?php $__currentLoopData = $keterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>"><?php echo e($k->keterangan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                        <label for="jenis" class="form-label">Jenis</label>
                        <select required name="jenis" id="select" class="form-control">
                            <option value="" disabled selected>Pilih Jenis Kas</option>
                            <option value="penerimaan">Penerimaan</option>
                            <option value="pengeluaran">Pengeluaran</option>
                        </select>
                        <br>
                        <label for="nominal" class="form-label">Nominal</label>
                        <input required type="number" class="form-control" name="nominal" id="nominal"
                            placeholder="Contoh: 200000">

                        <script>
                            // Daftar kombinasi tanggal dan keterangan_id yang sudah dipilih dari backend
                            const takenDatesWithKeterangan = <?php echo json_encode($takenDatesWithKeterangan, 15, 512) ?>;

                            document.getElementById('tanggalInput').addEventListener('change', validateDateAndCombination);
                            document.getElementById('select').addEventListener('change', validateDateAndCombination);

                            function validateDateAndCombination() {
                                const selectedDate = document.getElementById('tanggalInput').value;
                                const selectedKeterangan = document.getElementById('select').value;
                                const keteranganSelect = document.getElementById('select');

                                // Pastikan opsi "Pilih Keterangan" tetap disable
                                const placeholderOption = keteranganSelect.querySelector('option[value=""]');
                                if (placeholderOption) {
                                    placeholderOption.disabled = true;
                                }

                                // Validasi agar hanya tanggal Jumat yang bisa dipilih
                                const inputDate = new Date(selectedDate);
                                const dayOfWeek = inputDate.getUTCDay();
                                if (dayOfWeek !== 5) {
                                    alert("Silakan pilih tanggal yang jatuh pada hari Jumat.");
                                    document.getElementById('tanggalInput').value = "";
                                    return;
                                }

                                // Reset semua opsi keterangan untuk di-enable kembali
                                keteranganSelect.querySelectorAll('option').forEach(option => {
                                    if (option.value !== "") {
                                        option.disabled = false; // Enable opsi selain placeholder
                                    }
                                });

                                // Validasi kombinasi tanggal dan keterangan
                                const isTaken = takenDatesWithKeterangan.some(entry =>
                                    entry.tanggal === selectedDate && entry.keterangan_id == selectedKeterangan
                                );

                                if (isTaken) {
                                    alert("Kombinasi tanggal dan keterangan ini sudah dipilih. Silakan pilih kombinasi lain.");
                                    document.getElementById('tanggalInput').value = "";
                                    document.getElementById('select').value = "";
                                }

                                // Loop untuk disable opsi yang sudah terpilih di tanggal yang sama
                                takenDatesWithKeterangan.forEach(entry => {
                                    if (entry.tanggal === selectedDate) {
                                        const option = keteranganSelect.querySelector(`option[value="${entry.keterangan_id}"]`);
                                        if (option) {
                                            option.disabled = true; // Disable opsi yang sudah terpilih
                                        }
                                    }
                                });
                            }
                        </script>
                </div>


                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ini batas modal -->

    
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editModal<?php echo e($d->id); ?>" tabindex="-1" aria-labelledby="editModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel">Edit Data Kas Operasional</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('kas_operasional.update', $d->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <label for="tanggal" class="form-label">Tanggal</label>
                            <input required type="date" class="form-control" name="tanggal" id="tanggalInput"
                                aria-describedby="dateHelp" value="<?php echo e($d->tanggal); ?>">
                            <br>
                            <label for="keterangan_id" class="form-label">Nama Keterangan</label>
                            <select required name="keterangan_id" id="select" class="form-control">
                                <option value="" disabled selected>Pilih Keterangan</option>
                                <?php $__currentLoopData = $keterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k->id); ?>" <?php echo e($d->keterangan_id == $k->id ? 'selected' : ''); ?>>
                                        <?php echo e($k->keterangan); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <br>
                            <label for="jenis" class="form-label">Jenis</label>
                            <select required name="jenis" id="select" class="form-control">
                                <option value="" disabled selected>Pilih Jenis Kas</option>
                                <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($j); ?>" <?php echo e($d->jenis == $j ? 'selected' : ''); ?>>
                                        <?php echo e($j); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <br>
                            <label for="nominal" class="form-label">Nominal</label>
                            <input required type="number" class="form-control" name="nominal" id="nominal"
                                placeholder="Contoh: 200000" value="<?php echo e($d->nominal); ?>">

                            <script>
                                // Daftar kombinasi tanggal dan keterangan_id yang sudah dipilih dari backend
                                const takenDatesWithKeterangan = <?php echo json_encode($takenDatesWithKeterangan, 15, 512) ?>;

                                document.getElementById('tanggalInput').addEventListener('change', validateDateAndCombination);
                                document.getElementById('select').addEventListener('change', validateDateAndCombination);

                                function validateDateAndCombination() {
                                    const selectedDate = document.getElementById('tanggalInput').value;
                                    const selectedKeterangan = document.getElementById('select').value;
                                    const keteranganSelect = document.getElementById('select');

                                    // Pastikan opsi "Pilih Keterangan" tetap disable
                                    const placeholderOption = keteranganSelect.querySelector('option[value=""]');
                                    if (placeholderOption) {
                                        placeholderOption.disabled = true;
                                    }

                                    // Validasi agar hanya tanggal Jumat yang bisa dipilih
                                    const inputDate = new Date(selectedDate);
                                    const dayOfWeek = inputDate.getUTCDay();
                                    if (dayOfWeek !== 5) {
                                        alert("Silakan pilih tanggal yang jatuh pada hari Jumat.");
                                        document.getElementById('tanggalInput').value = "";
                                        return;
                                    }

                                    // Reset semua opsi keterangan untuk di-enable kembali
                                    keteranganSelect.querySelectorAll('option').forEach(option => {
                                        if (option.value !== "") {
                                            option.disabled = false; // Enable opsi selain placeholder
                                        }
                                    });

                                    // Validasi kombinasi tanggal dan keterangan
                                    const isTaken = takenDatesWithKeterangan.some(entry =>
                                        entry.tanggal === selectedDate && entry.keterangan_id == selectedKeterangan
                                    );

                                    if (isTaken) {
                                        alert("Kombinasi tanggal dan keterangan ini sudah dipilih. Silakan pilih kombinasi lain.");
                                        document.getElementById('tanggalInput').value = "";
                                        document.getElementById('select').value = "";
                                    }

                                    // Loop untuk disable opsi yang sudah terpilih di tanggal yang sama
                                    takenDatesWithKeterangan.forEach(entry => {
                                        if (entry.tanggal === selectedDate) {
                                            const option = keteranganSelect.querySelector(`option[value="${entry.keterangan_id}"]`);
                                            if (option) {
                                                option.disabled = true; // Disable opsi yang sudah terpilih
                                            }
                                        }
                                    });
                                }
                            </script>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <div class="container-fluid px-4">
        <h1 class="mt-4">Data Kas Operasional</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="dashboard">Dashboard</a></li>
            <li class="breadcrumb-item active">Tables</li>
        </ol>
        <div class="card mb-4">

        </div>
        <?php if(auth()->guard()->check()): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="" class="btn btn-md btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            <i class="fa-solid fa-square-plus"></i>
                        </a>
                        <a href="kas/print" target="_blank" class="btn btn-md btn-success">
                            <i class="fa-solid fa-print"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>No</th>

                                <th>Tanggal</th>
                                <th>Keterangan</th>
                                <th>Jenis</th>
                                <th>Nominal</th>

                                <th>Action</th>

                            </tr>
                        </thead>
                        <tfoot>
                            <th>No</th>

                            <th>Tanggal</th>
                            <th>Keterangan</th>
                            <th>Jenis</th>
                            <th>Nominal</th>

                            <th>Action</th>
                        </tfoot>
                        <tbody>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>

                                    <td><?php echo e($d->tanggal); ?></td>
                                    <td><?php echo e($d->keterangan); ?></td>
                                    <td><?php echo e($d->jenis); ?></td>
                                    <td><?php echo e(number_format($d->nominal, 0, ',', '.')); ?>

                                    </td>


                                    <td>
                                        
                                        <a href="#" class="btn btn-sm btn-warning" data-bs-toggle="modal"
                                            data-bs-target="#editModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-pen-to-square"></i></a>

                                        <!-- ini untuk modal hapus -->
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal<?php echo e($d->id); ?>">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal<?php echo e($d->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus Produk</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Apakah anda yakin akan menghapus data tanggal <?php echo e($d->tanggal); ?>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>

                                                        <form action="<?php echo e(route('kas_operasional.destroy', $d->id)); ?>"
                                                            method="POST" style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </form>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- ini batas modal hapus -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fullstack-web\repo-bang-aripp\repo-bang-arip\resources\views/admin/kasOperasional/index.blade.php ENDPATH**/ ?>