<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        //
       $middleware->web([
        \RealRashid\SweetAlert\ToSweetAlert::class,
       ]);
       $middleware->alias([
        'Alert' => RealRashid\SweetAlert\Facades\Alert::class,
        'role' => App\Http\Middleware\Role::class,
        'checkActive' => App\Http\Middleware\CheckActive::class,
       ]);

    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
